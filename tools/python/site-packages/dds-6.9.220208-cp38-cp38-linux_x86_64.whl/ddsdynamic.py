try:
    from dataclasses import fields, is_dataclass, dataclass
    from typing import NewType, get_origin, get_args
    from xml.etree.ElementTree import Element, SubElement, tostring
except ImportError:
    pass


char = NewType("char", int)
wchar = NewType("wchar", int)
int16 = NewType("int16", int)
int32 = NewType("int32", int)
int64 = NewType("int64", int)
uint8 = NewType("uint8", int)
uint16 = NewType("uint16", int)
uint32 = NewType("uint32", int)
uint64 = NewType("uint64", int)
float32 = NewType("float32", float)
float64 = NewType("float64", float)

primitive_xml_mapping = {
    int16: "Short",
    uint16: "UShort",
    int32: "Long",
    uint32: "ULong",
    int64: "LongLong",
    uint64: "ULongLong",
    float32: "Float",
    float64: "Double",
    char: "Char",
    uint8: "Octet",

    bool: "Boolean",
    int: "LongLong"
}


class Registry:
    def __init__(self, root):
        self.root = root
        self.structs = {}


class Machine:
    """Given a type, return XML unit"""
    def __init__(self, type):
        self.type = type

    def xml(self, registry, parent):
        pass

    def descriptor(self):
        md = Element("MetaData")
        md.set("version", "1.0.0")
        mod = SubElement(md, "Module")
        mod.set("name", "PythonDynamic")
        reg = Registry(mod)
        self.xml(reg, mod)
        return tostring(md)


class PrimitiveMachine(Machine):
    def xml(self, registry, parent):
        SubElement(parent, primitive_xml_mapping[self.type])


class StringMachine(Machine):
    def __init__(self):
        pass

    def xml(self, registry, parent):
        SubElement(parent, "String")


class SequenceMachine(Machine):
    def __init__(self, submachine):
        self.submachine = submachine

    def xml(self, registry, parent):
        self.submachine.xml(registry, SubElement(parent, "Sequence"))


class StructMachine(Machine):
    def __init__(self, root, object, members_machines):
        self.root = root
        self.type = object
        self.members_machines = members_machines

    def xml(self, registry, parent):
        name = self.type.__name__

        if self.root:
            e = Element("Struct")
            e.set('name', name)

            for n, m in self.members_machines.items():
                mxml = SubElement(e, "Member")
                mxml.set('name', n)
                m.xml(registry, mxml)

            # Using an Element and extending later makes sure this struct is at the end
            parent.extend([e])
        else:
            e = SubElement(parent, "Type")
            e.set("name", name)

            if name not in registry.structs:
                e = SubElement(registry.root, "Struct")
                e.set('name', name)

                for n, m in self.members_machines.items():
                    mxml = SubElement(e, "Member")
                    mxml.set('name', n)
                    m.xml(registry, mxml)



def build_machine(_type, root=False):
    if _type == str:
        return StringMachine()
    elif _type in primitive_xml_mapping:
        return PrimitiveMachine(_type)
    elif get_origin(_type) == list:
        return SequenceMachine(build_machine(get_args(_type)[0]))
    elif isinstance(_type, object):
        if not is_dataclass(_type):
            _type = dataclass(_type)
        _fields = fields(_type)
        _members = { f.name: build_machine(f.type) for f in _fields }
        return StructMachine(root, _type, _members)

    raise Exception(f"Could not make xml descriptor machinery for type {_type}.")


def xml_descriptor_of(cls):
    return build_machine(cls, True).descriptor().decode()

